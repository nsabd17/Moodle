<?php
defined('MOODLE_INTERNAL') || die();

class local_restapi_myservice_external extends external_api {
    public static function hello_world_parameters() {
        return new external_function_parameters(
            array()
        );
    }

    public static function hello_world() {
        return "Hello, world!";
    }
}
