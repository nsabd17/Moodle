<?php
defined('MOODLE_INTERNAL') || die();
$plugin->component = 'local_restapi_myservice';
$plugin->version = 2022040400;