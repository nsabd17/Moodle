<?php
defined('MOODLE_INTERNAL') || die();

$functions = array(
    'local_myservice_hello_world' => array(
        'classname' => 'local_restapi_myservice_external',
        'methodname' => 'hello_world',
        'description' => 'Return a greeting message',
        'type' => 'read',
        'capabilities' => 'local/restapi:usemyservice',
    ),
);

$services = array(
    'MyService' => array(
        'functions' => array('local_restapi_myservice_hello_world'),
        'restrictedusers' => 0,
        'enabled' => 1,
    )
);
