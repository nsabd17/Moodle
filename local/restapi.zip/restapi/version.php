<?php
$plugin->component = 'local_restapi'; // Plugin type and name
$plugin->version = 2022040400; // Plugin version
$plugin->release = 'v1.0'; // Release name
$plugin->requires = 2020110900; // Moodle version required
$plugin->maturity = MATURITY_STABLE; // Maturity level
