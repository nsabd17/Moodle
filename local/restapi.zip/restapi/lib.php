<?php
defined('MOODLE_INTERNAL') || die();

// No specific functionality for the plugin's main file
