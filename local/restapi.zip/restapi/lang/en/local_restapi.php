<?php
$string['pluginname'] = 'Local Restapi';
