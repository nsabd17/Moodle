<?php
$string['pluginname'] = 'Mstar Custom Services';