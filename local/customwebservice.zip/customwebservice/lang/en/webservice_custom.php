<?php

$string['pluginname'] = 'Custom Web Service';
$string['pluginname_desc'] = 'Description of your custom web service.';

?>
