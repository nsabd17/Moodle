<?php
// English language strings for the customblock block plugin.

$string['pluginname'] = 'Custom Block'; // Display name for the block.
$string['customblock:addinstance'] = 'Add a new custom block'; // Permission string.
$string['customblock:myaddinstance'] = 'Add a new custom block to the My Moodle page'; // Permission string.
// Add more language strings as needed.

